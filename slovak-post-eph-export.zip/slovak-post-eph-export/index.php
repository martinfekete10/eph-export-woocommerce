<?php

    // Silence is golden
